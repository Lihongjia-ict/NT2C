import glob
import random
import os
import numpy as np

import mrcfile

from torch.utils.data import Dataset
from PIL import Image
import torchvision.transforms as transforms

import mrc as mrc



def load_mrc(path, standardize=False):
    with open(path, 'rb') as f:
        content = f.read()
    image, header, extended_header = mrc.parse(content)
    if standardize:
        image = image - header.amean
        image /= header.rms
    return Image.fromarray(image)

def load_image(path):
    x = np.array(load_mrc(path), copy=False)
    x = x.astype(np.float32) # make sure dtype is single precision
    mu = x.mean()
    std = x.std()
    x = (x - mu)/std
    return x
'''
def normalize(img):
    img_max=np.max(img)
    img_min=np.min(img)
    #print(img)
    img_new=(img-img_min)/float(img_max-img_min)
#    img_new=(img-img_min)/float(img_max-img_min)*255.0
    #print(img_new)
    return img_new
'''

class ImageDataset(Dataset):
    def __init__(self, root, transforms_=None, mode="train"):
        self.transform = transforms.Compose(transforms_)

        #self.files = sorted(glob.glob(os.path.join(root, mode) + "/*.*"))
        self.files = sorted(glob.glob(root + "/*.*"))
        if mode == "train":
            self.files.extend(sorted(glob.glob(os.path.join(root, "test") + "/*.*")))

    def __getitem__(self, index):

        #img = Image.open(self.files[index % len(self.files)])
        #img = np.array(img)
        #img=mrcfile.open(self.files[index % len(self.files)])
        #img=normalize(img.data)
        img=load_image(self.files[index % len(self.files)])

#        w, h = img.size
#        img_A = img.crop((0, 0, w / 2, h))
#        img_B = img.crop((w / 2, 0, w, h))

#        if np.random.random() < 0.5:
#            img_A = Image.fromarray(np.array(img_A)[:, ::-1, :], "RGB")
#            img_B = Image.fromarray(np.array(img_B)[:, ::-1, :], "RGB")

#        img = self.transform(img[:,:,0])
        img = self.transform(img)
#        print(img.data)

#        img_B = self.transform(img_B)

#        return {"A": img_A, "B": img_B}
        return{"img":img}
    def __len__(self):
        return len(self.files)

